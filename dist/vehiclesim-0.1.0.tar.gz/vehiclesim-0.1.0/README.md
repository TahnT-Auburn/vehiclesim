# Vehicle Simulation Python Package

## Package Description:
A python package that houses various vehicle simulators.

***
## TractorTrailer Class:
### Description:
Tractor trailer vehicle simulator.
## Dependencies:
* numpy
* python_utilities
## Methods:
{add methods}